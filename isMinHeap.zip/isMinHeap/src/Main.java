import java.util.Scanner;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        minHeap heapmi = new minHeap();
        üçlüMinHeap heapyap = new üçlüMinHeap();

        Scanner input = new Scanner(System.in);

        System.out.println("Liste Giriniz:");
        String bilgi = input.nextLine();

        String[] yazi = bilgi.split(",");

        int dizi[] = new int[yazi.length];

        int sayac=0;
        for (String a : yazi) {
            System.out.println(a);
            int yeni1 = Integer.parseInt(a);
            dizi[sayac] = yeni1;
            sayac++;
        }

        if (heapmi.isTripleMinHeap(dizi)) {
            System.out.println("bu liste 3'lü minheaptir");
            System.out.println(Arrays.toString(dizi));
        }
        else {
            System.out.println("bu liste 3'lü minheap değildir");
            System.out.println(Arrays.toString(dizi));
            heapyap.tripleMinHeapify(dizi);
            System.out.println(Arrays.toString(dizi));


        }
    }
}