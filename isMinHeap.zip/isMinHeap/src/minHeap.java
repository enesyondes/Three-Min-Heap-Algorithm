public class minHeap {
    public static boolean isTripleMinHeap(int[] array) {
        for (int i = 0; i < array.length * 2 / 3; i++) {
            int ilkCocuk = 3 * i + 1;
            int ikinciCocuk = 3 * i + 2;
            int ucuncuCocuk = 3 * i + 3;

            if (ilkCocuk < array.length && array[i] > array[ilkCocuk]) {
                return false;
            }

            if (ikinciCocuk < array.length && array[i] > array[ikinciCocuk]) {
                return false;
            }

            if (ucuncuCocuk < array.length && array[i] > array[ucuncuCocuk]) {
                return false;
            }
        }
        return true;
    }
}
