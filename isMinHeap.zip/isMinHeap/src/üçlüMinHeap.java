public class üçlüMinHeap {
    public static void tripleMinHeapify(int[] array) {
        for (int i = array.length * 2 / 3 - 1; i >= 0; i--) {
            int değer = i;
            int ilkCocuk = 3 * i + 1;

            if (ilkCocuk < array.length && array[değer] > array[ilkCocuk]) {
                int temp = array[değer];
                array[değer] = array[ilkCocuk];
                array[ilkCocuk] = temp;
                değer = ilkCocuk;
            }
            int ikinciCocuk = 3 * i + 2;

            if (ikinciCocuk < array.length && array[değer] > array[ikinciCocuk]) {
                int temp = array[değer];
                array[değer] = array[ikinciCocuk];
                array[ikinciCocuk] = temp;
                değer = ikinciCocuk;
            }
            int ücüncüCocuk = 3 * i + 3;

            if (ücüncüCocuk < array.length && array[değer] > array[ücüncüCocuk]) {
                int temp = array[değer];
                array[değer] = array[ücüncüCocuk];
                array[ücüncüCocuk] = temp;
            }
        }
    }
}